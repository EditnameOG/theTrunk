fx_version 'cerulean'
game 'gta5'

description 'TheTrunk'

client_scripts {
    'trunk.lua'
}
