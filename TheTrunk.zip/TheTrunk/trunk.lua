-- Configuration
Config = {}
Config.OpenCloseKey = 38    -- Default: E
Config.HideInTrunkKey = 47  -- Default: G

local isTrunkOpen = false
local isHidingInTrunk = false

-- Utility function to check if the player is near a vehicle's trunk
function IsNearTrunk()
    local playerPed = PlayerPedId()
    local pos = GetEntityCoords(playerPed)
    local vehicle = GetClosestVehicle(pos.x, pos.y, pos.z, 3.0, 0, 70)

    if DoesEntityExist(vehicle) then
        local trunkPos = GetWorldPositionOfEntityBone(vehicle, GetEntityBoneIndexByName(vehicle, "boot"))
        local dist = #(pos - trunkPos)
        return dist < 2.0, vehicle
    end
    return false, nil
end

-- Toggle trunk open/close
function ToggleTrunk(vehicle)
    local trunk = GetEntityBoneIndexByName(vehicle, "boot")
    if trunk ~= -1 then
        if isTrunkOpen then
            SetVehicleDoorShut(vehicle, 5, false)
            isTrunkOpen = false
        else
            SetVehicleDoorOpen(vehicle, 5, false, false)
            isTrunkOpen = true
        end
    end
end

-- Hide in trunk
function ToggleHideInTrunk(vehicle)
    local playerPed = PlayerPedId()
    if isHidingInTrunk then
        ClearPedTasksImmediately(playerPed)
        SetEntityVisible(playerPed, true, false)
        isHidingInTrunk = false
    else
        local trunkPos = GetWorldPositionOfEntityBone(vehicle, GetEntityBoneIndexByName(vehicle, "boot"))
        SetEntityCoords(playerPed, trunkPos.x, trunkPos.y, trunkPos.z - 0.5)
        SetEntityVisible(playerPed, false, false)
        isHidingInTrunk = true
    end
end

-- Main control loop
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local isNear, vehicle = IsNearTrunk()

        if isNear and not isHidingInTrunk then
            -- Display help text
            SetTextComponentFormat("STRING")
            AddTextComponentString("Press ~INPUT_CONTEXT~ to open/close trunk")
            DisplayHelpTextFromStringLabel(0, 0, 1, -1)

            -- Open/close trunk
            if IsControlJustReleased(0, Config.OpenCloseKey) then
                ToggleTrunk(vehicle)
            end

            -- Hide in trunk
            if IsControlJustReleased(0, Config.HideInTrunkKey) then
                ToggleHideInTrunk(vehicle)
            end
        elseif isHidingInTrunk then
            -- Get out of trunk
            if IsControlJustReleased(0, Config.HideInTrunkKey) then
                ToggleHideInTrunk(vehicle)
            end
        end
    end
end)
